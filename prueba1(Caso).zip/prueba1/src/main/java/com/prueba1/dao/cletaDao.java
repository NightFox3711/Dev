package com.prueba1.dao;
import com.prueba1.domain.cleta;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 *
 * @author NightFox
 */
public interface cletaDao extends JpaRepository <cleta, Long> {
    
}
